#include <iostream>
using namespace std;
int main() {
 int P,R,T,SI;
 cin>>P>>R>>T;
 SI = P*R*T/100;
 cout<<"Simple Interest is "<<SI;
    return 0;
}