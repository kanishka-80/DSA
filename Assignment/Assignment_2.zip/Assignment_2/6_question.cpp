// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
int main() {
 int marks;
 cin>>marks;
 if(marks >=90){
     cout<<"A";
 }else if(marks>=75 and marks<=90) {
     cout<<"B";
 }else if(marks>=65 and marks<=75){
     cout<<"C";
 }else{
     cout<<"D";
 }
 

    return 0;
}

 